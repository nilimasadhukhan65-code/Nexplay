package com.nexplay.hub

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var gameList: LinearLayout
    private lateinit var memoryText: TextView
    private lateinit var subtitleText: TextView
    private lateinit var refreshButton: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gameList = findViewById(R.id.gameList)
        memoryText = findViewById(R.id.memoryText)
        subtitleText = findViewById(R.id.subtitleText)
        refreshButton = findViewById(R.id.refreshButton)

        refreshButton.setOnClickListener { loadLibrary() }
        loadLibrary()
    }

    private fun loadLibrary() {
        gameList.removeAllViews()
        updateMemory()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)

        val apps = try {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        } catch (_: Exception) {
            emptyList()
        }.mapNotNull { info ->
            val appInfo = info.activityInfo?.applicationInfo ?: return@mapNotNull null
            if (appInfo.packageName == packageName) return@mapNotNull null
            Triple(
                info.loadLabel(pm)?.toString() ?: appInfo.packageName,
                appInfo.packageName,
                info.loadIcon(pm)
            )
        }.distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        subtitleText.text = "${apps.size} launchable apps found • Games may appear with other apps"

        if (apps.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No launchable apps found."
                setTextColor(Color.LTGRAY)
                textSize = 14f
                setPadding(12, 24, 12, 24)
            }
            gameList.addView(empty)
            return
        }

        apps.forEach { (label, packageName, icon) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 14, 14, 14)
                setBackgroundColor(Color.rgb(18, 29, 48))
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.bottomMargin = dp(10)
                layoutParams = params
            }

            val appIcon = ImageView(this).apply {
                setImageDrawable(icon)
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            }
            card.addView(appIcon)

            val name = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 2
                setPadding(dp(12), 0, dp(8), 0)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            card.addView(name)

            val launch = TextView(this).apply {
                text = "PLAY"
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(11), dp(16), dp(11))
                setBackgroundColor(Color.rgb(30, 125, 220))
                contentDescription = "Launch $label"
                setOnClickListener { optimizeAndLaunch(packageName, label) }
            }
            card.addView(launch)
            card.setOnClickListener { optimizeAndLaunch(packageName, label) }
            gameList.addView(card)
        }
    }

    private fun optimizeAndLaunch(targetPackage: String, label: String) {
        // Android does not allow ordinary apps to force-stop unrelated background apps.
        // This only asks Android to trim this app's own memory before launching the game.
        try {
            onTrimMemory(TRIM_MEMORY_RUNNING_LOW)
        } catch (_: Exception) { }

        updateMemory()
        val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
        if (launchIntent == null) {
            Toast.makeText(this, "Cannot launch $label", Toast.LENGTH_SHORT).show()
            return
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launchIntent)
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to start $label", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateMemory() {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(memory)
        val availableGb = memory.availMem / (1024.0 * 1024.0 * 1024.0)
        val totalGb = memory.totalMem / (1024.0 * 1024.0 * 1024.0)
        memoryText.text = "SYSTEM STATUS  •  ${"%.1f".format(availableGb)} GB AVAILABLE / ${"%.1f".format(totalGb)} GB TOTAL\nBOOST MODE  •  SAFE REFRESH READY"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
