# NEXPLAY Android

A PS5-inspired game library and launcher for Android 9+.

## Features
- Lists launchable apps installed on the phone (Android does not reliably label every game as a game).
- Launches a selected game using its normal Android launch intent.
- Shows available memory and offers a safe refresh/launch flow.
- Dark console-style interface with blue accents.

## Important Android limitation
A normal Android app cannot force-stop other apps or freely clear their processes/RAM. NEXPLAY does not claim to do that. Its refresh action refreshes the library and asks Android to trim this app's own memory before launching the selected game.

## Build on GitHub
1. Extract this ZIP into a GitHub repository (the project files must be at the repository root).
2. Push the extracted files to GitHub.
3. GitHub Actions will build a debug APK using `.github/workflows/android.yml`.
4. Download the APK from the workflow run's Artifacts section.

Uploading the ZIP as a single file without extracting it will not make GitHub Actions recognize it as an Android project.

## Requirements
- Android 9 (API 28) or newer.
- No root required.
